/*
 * Created on Apr 1, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.zerog.ia.customcode.action;

import java.io.*;

import com.zerog.ia.api.pub.*;

/**
 * @author abir
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class AppleVMSet extends CustomCodeAction
{

	/* (non-Javadoc)
	 * @see com.zerog.ia.api.pub.CustomCodeAction#install(com.zerog.ia.api.pub.InstallerProxy)
	 */
	public void install(InstallerProxy ip) throws InstallException
	{
		// TODO Auto-generated method stub
		String appLocation = ip.substitute("$APP_LOCATION$");
		if (!appLocation.endsWith(".app"))
		{
			appLocation += ".app";
		}
		System.err.println("appLocation: " + appLocation);
		File infoPlist = new File(appLocation + "/Contents/Info.plist");
		System.err.println("infoPlist.exists(): " + infoPlist.exists());
		
		File infoPlistOld = new File(appLocation + "/Contents/Info.plist.bak");		
		infoPlist.renameTo(infoPlistOld);		

		manipulateFile(infoPlistOld.getAbsolutePath(),infoPlist.getAbsolutePath());
	}

	/* (non-Javadoc)
	 * @see com.zerog.ia.api.pub.CustomCodeAction#uninstall(com.zerog.ia.api.pub.UninstallerProxy)
	 */
	public void uninstall(UninstallerProxy up) throws InstallException
	{
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see com.zerog.ia.api.pub.CustomCodeAction#getInstallStatusMessage()
	 */
	public String getInstallStatusMessage()
	{
		// TODO Auto-generated method stub
		return "Updating Application";
	}

	/* (non-Javadoc)
	 * @see com.zerog.ia.api.pub.CustomCodeAction#getUninstallStatusMessage()
	 */
	public String getUninstallStatusMessage()
	{
		// TODO Auto-generated method stub
		return "";
	}

	public void manipulateFile(String fileInput, String fileOutput) 
	{
		BufferedReader fileBuffreader = null;
		PrintWriter writer = null;

		//System.err.println("fileInput:  "+fileInput);
		//System.err.println("fileOutput: "+fileOutput);

		try
		{
			
			fileBuffreader = new BufferedReader(new FileReader(new File(fileInput) ));
			writer = new PrintWriter(new FileOutputStream(new File(fileOutput)));
			
			String tempStr = "";
			
			tempStr = fileBuffreader.readLine();
			
			int dictCount=0;
			boolean locationFound=false;	
			while (tempStr != null)
			{
				//System.err.println("Reading: "+tempStr);
				writer.println(tempStr);
				
				if (tempStr.indexOf("<dict>") != -1 && locationFound ==false)
				{
						dictCount++;
				}
				//System.err.println("DictCount:"+dictCount);
				if(dictCount == 2  && !locationFound)
				{
					//System.err.println("Found location, inserting here");
					writer.println("<key>JVMVersion</key>");
					writer.println("<string>1.4+</string>");
					locationFound=true;
				}
					
				tempStr = fileBuffreader.readLine();			
			}			
						
			if (fileBuffreader != null) fileBuffreader.close();
			
			if (writer != null) 
			{
				writer.flush();
				writer.close();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			
			//if (fileBuffreader != null) fileBuffreader.close();
			
			if (writer != null)
			{
				writer.flush();
				writer.close();
			}
		}
	}

}
